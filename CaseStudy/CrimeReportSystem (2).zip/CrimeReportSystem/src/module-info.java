/**
 * 
 */
/**
 * 
 */
module CrimeReportSystem {
	requires java.sql;
	requires org.junit.jupiter.api;
} 