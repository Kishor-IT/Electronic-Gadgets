package com.crime.exception;

public class ReportGenerationException extends Exception {
    public ReportGenerationException(String message) {
        super(message);
    }
}
