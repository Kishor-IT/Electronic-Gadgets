package com.crime.exception;

public class IncidentNotFoundException extends Exception {
    public IncidentNotFoundException(String message) {
        super(message);
    }
}
