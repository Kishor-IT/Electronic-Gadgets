package com.crime.main;

import com.crime.Incident;
import com.crime.Report;
import com.crime.dao.CrimeAnalysisServiceImpl;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class MainModule {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        CrimeAnalysisServiceImpl service = new CrimeAnalysisServiceImpl();

        while (true) {
            System.out.println("\n=== Crime Analysis and Reporting System ===");
            System.out.println("1. Create New Incident");
            System.out.println("2. Update Incident Status");
            System.out.println("3. Search Incidents by Type");
            System.out.println("4. View Incidents in Date Range");
            System.out.println("5. Generate Report by Incident ID");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");
            int ch = sc.nextInt();
            sc.nextLine();

            switch (ch) {
                case 1:
                    System.out.print("Enter Incident ID: ");
                    int id = sc.nextInt(); sc.nextLine();
                    System.out.print("Enter Type: ");
                    String type = sc.nextLine();
                    System.out.print("Enter Date (yyyy-mm-dd): ");
                    LocalDate date = LocalDate.parse(sc.nextLine());
                    System.out.print("Enter Location: ");
                    String loc = sc.nextLine();
                    System.out.print("Enter Description: ");
                    String desc = sc.nextLine();
                    System.out.print("Enter Status: ");
                    String status = sc.nextLine();
                    System.out.print("Enter Victim ID: ");
                    int vid = sc.nextInt();
                    System.out.print("Enter Suspect ID: ");
                    int sid = sc.nextInt();
                    System.out.print("Enter Officer ID: ");
                    int oid = sc.nextInt();
                    Incident incident = new Incident(id, type, Date.valueOf(date), loc, desc, status, vid, sid, oid);
                    boolean res = service.createIncident(incident);
                    System.out.println(res ? " Incident added." : " Failed to add.");
                    break;

                case 2:
                    System.out.print("Enter Incident ID to Update: ");
                    int incidentId = sc.nextInt(); sc.nextLine();
                    System.out.print("Enter New Status: ");
                    String newStatus = sc.nextLine();
                    boolean updated = service.updateIncidentStatus(incidentId, newStatus);
                    System.out.println(updated ? " Status updated." : "Update failed.");
                    break;

                case 3:
                    System.out.print("Enter Incident Type to Search: ");
                    String searchType = sc.nextLine();
                    List<Incident> found = service.searchIncidents(searchType);
                    if (found.isEmpty()) {
                        System.out.println("No incidents found with type: " + searchType);
                    } else {
                        for (Incident i : found) {
                            System.out.println(i);  
                        }
                    }
                    break;

                case 4:
                    System.out.print("Enter Start Date (yyyy-mm-dd): ");
                    LocalDate start = LocalDate.parse(sc.nextLine());
                    System.out.print("Enter End Date (yyyy-mm-dd): ");
                    LocalDate end = LocalDate.parse(sc.nextLine());
                    List<Incident> rangeList = service.getIncidentsInDateRange(start, end);
                    if (rangeList.isEmpty()) {
                        System.out.println("No incidents found in date range.");
                    } else {
                        for (Incident i : rangeList) {
                            System.out.println(i);
                        }
                    }
                    break;

                case 5:
                    System.out.print("Enter Incident ID for Report: ");
                    int rid = sc.nextInt();
                    Object report = service.generateIncidentReport(rid);
                    if (report == null) {
                        System.out.println("No report found.");
                    } else {
                        System.out.println("\n=== Incident Report ===");
                        System.out.println(report);
                    }
                    break;

                case 0:
                    System.out.println("Thank You !!!");
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}
