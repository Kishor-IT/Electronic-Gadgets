package com.crime.main;

import com.crime.Incident;
import com.crime.dao.CrimeAnalysisServiceImpl;

import java.time.LocalDate;
import java.sql.Date;

public class IncidentCreationExample {

    public static void main(String[] args) {
      
        CrimeAnalysisServiceImpl service = new CrimeAnalysisServiceImpl();

        LocalDate localDate = LocalDate.of(2025, 4, 15);

        Date sqlDate = Date.valueOf(localDate);

        Incident incident = new Incident(
            3001, 
            "Theft",
            sqlDate, 
            "Mumbai",
            "Mobile phone stolen in a crowded train",
            "Open",
            101, 
            201,  
            301  
            );

        
        boolean created = service.createIncident(incident);

       
        if (created) {
            System.out.println("Incident created successfully.");
        } else {
            System.out.println("Failed to create incident.");
        }
    }
}
