package com.crime.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class DBPropertyUtil {

    private static final String FILE_PATH = "db.properties";

    public static Properties loadProperties() {
        Properties props = new Properties();
        try (FileInputStream fis = new FileInputStream(FILE_PATH)) {
            props.load(fis);
        } catch (IOException e) {
            System.err.println("Failed to load DB properties: " + e.getMessage());
        }
        return props;
    }
}
