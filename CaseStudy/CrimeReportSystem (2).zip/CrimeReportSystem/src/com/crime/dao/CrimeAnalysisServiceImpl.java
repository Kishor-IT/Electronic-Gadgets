package com.crime.dao;

import com.crime.Incident;
import com.crime.util.DBConnUtil;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class CrimeAnalysisServiceImpl implements ICrimeAnalysisService {

    private static Connection connection;

    public CrimeAnalysisServiceImpl() {
        connection = DBConnUtil.getConnection();
    }

    @Override
    public boolean createIncident(Incident incident) {
        String query = "INSERT INTO Incidents (IncidentID, IncidentType, IncidentDate, Location, Descriptions, Status, VictimID, SuspectID, OfficerID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, incident.getIncidentId());
            ps.setString(2, incident.getIncidentType());
            ps.setDate(3, incident.getIncidentDate());
            ps.setString(4, incident.getLocation());
            ps.setString(5, incident.getDescription());
            ps.setString(6, incident.getStatus());
            ps.setInt(7, incident.getVictimId());
            ps.setInt(8, incident.getSuspectId());
            ps.setInt(9, incident.getOfficerId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("SQL eroor code: "+e.getErrorCode());
            System.err.println("SQL state: "+e.getSQLState());
            System.err.println("Message: "+e.getMessage());
        }
        return false;
    }

    @Override
    public boolean updateIncidentStatus(int incidentId, String status) {
        String query = "UPDATE Incidents SET Status = ? WHERE IncidentID = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, status);
            ps.setInt(2, incidentId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public List<Incident> getIncidentsInDateRange(Date startDate, Date endDate) {
        List<Incident> list = new ArrayList<>();
        String query = "SELECT * FROM Incidents WHERE IncidentDate BETWEEN ? AND ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setDate(1, startDate);
            ps.setDate(2, endDate);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Incident incident = new Incident(
                    rs.getInt("IncidentID"),
                    rs.getString("IncidentType"),
                    rs.getDate("IncidentDate"),
                    rs.getString("Location"),
                    rs.getString("Descriptions"),
                    rs.getString("Status"),
                    rs.getInt("VictimID"),
                    rs.getInt("SuspectID"),
                    rs.getInt("OfficerID")
                );
                list.add(incident);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public List<Incident> getIncidentsInDateRange(LocalDate startDate, LocalDate endDate) {
        return getIncidentsInDateRange(Date.valueOf(startDate), Date.valueOf(endDate));
    }

    @Override
    public List<Incident> searchIncidents(String incidentType) {
        List<Incident> list = new ArrayList<>();
        String query = "SELECT * FROM Incidents WHERE IncidentType = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, incidentType);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Incident incident = new Incident(
                    rs.getInt("IncidentID"),
                    rs.getString("IncidentType"),
                    rs.getDate("IncidentDate"),
                    rs.getString("Location"),
                    rs.getString("Descriptions"),
                    rs.getString("Status"),
                    rs.getInt("VictimID"),
                    rs.getInt("SuspectID"),
                    rs.getInt("OfficerID")
                );
                list.add(incident);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public Object generateIncidentReport(int incidentId) {
        Incident incident = getIncidentById(incidentId);
        if (incident == null) {
            return "No incident found with ID: " + incidentId;
        }

        return "Report for Incident:\n" +
               "ID: " + incident.getIncidentId() + "\n" +
               "Type: " + incident.getIncidentType() + "\n" +
               "Date: " + incident.getIncidentDate() + "\n" +
               "Location: " + incident.getLocation() + "\n" +
               "Status: " + incident.getStatus();
    }

    @Override
    public Incident getIncidentById(int incidentId) {
        Incident incident = null;
        String query = "SELECT * FROM Incidents WHERE IncidentID = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, incidentId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                incident = new Incident(
                    rs.getInt("IncidentID"),
                    rs.getString("IncidentType"),
                    rs.getDate("IncidentDate"),
                    rs.getString("Location"),
                    rs.getString("Descriptions"),
                    rs.getString("Status"),
                    rs.getInt("VictimID"),
                    rs.getInt("SuspectID"),
                    rs.getInt("OfficerID")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return incident;
    }
}
