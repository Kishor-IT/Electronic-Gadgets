package com.crime.dao;

import com.crime.Incident;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

public interface ICrimeAnalysisService {

    boolean createIncident(Incident incident); //given

    boolean updateIncidentStatus(int incidentId, String status); //given

    List<Incident> getIncidentsInDateRange(Date startDate, Date endDate);  //given       
    
    List<Incident> getIncidentsInDateRange(LocalDate startDate, LocalDate endDate); 

    List<Incident> searchIncidents(String incidentType); //given

    Object generateIncidentReport(int incidentId); // given 

    Incident getIncidentById(int incidentId);
}
