package com.test;

import com.crime.dao.CrimeAnalysisServiceImpl;
import com.crime.Incident;
import com.crime.exception.IncidentNotFoundException;

import org.junit.jupiter.api.*;

import java.sql.Date;

import static org.junit.jupiter.api.Assertions.*;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class CrimeAnalysisServiceImplTest {

    private static CrimeAnalysisServiceImpl service;

    @BeforeAll
    public static void setup() {
        service = new CrimeAnalysisServiceImpl();
    }

    @Test
    @Order(1)
    public void testCreateIncident_Success() {
        Incident incident = new Incident(
            2001, "Robbery", Date.valueOf("2025-04-01"),
            "Downtown", "ATM looting", "Open",
            1, 2, 3
        );

        boolean result = service.createIncident(incident);
        assertTrue(result, "Incident should be created successfully");
    }
    @Test
    @Order(2)
    public void testCreateIncident_InvalidData() {
        Incident incident = new Incident(
            0, null, null, "", "", "", 0, 0, 0
        );

        boolean result = service.createIncident(incident);
        assertFalse(result, "Incident with invalid data should not be created");
    }

    @Test
    @Order(3)
    public void testUpdateIncidentStatus_Success() throws IncidentNotFoundException {
       
        boolean result = service.updateIncidentStatus(2001, "Closed");
        assertTrue(result, "Incident status should be updated");
    }

    @Test
    @Order(4)
    public void testUpdateIncidentStatus_InvalidId() {
        assertThrows(IncidentNotFoundException.class, () -> {
        
            service.updateIncidentStatus(9999, "Closed");
        }, "Should throw IncidentNotFoundException for invalid ID");
    }

    @Test
    @Order(5)
    public void testVerifyCreatedIncidentData() throws IncidentNotFoundException {
        Incident incident = service.getIncidentById(2001); 
        assertNotNull(incident);
        assertEquals("Robbery", incident.getIncidentType());
        assertEquals("Open", incident.getStatus());
        assertEquals("Downtown", incident.getLocation());
    }
}
