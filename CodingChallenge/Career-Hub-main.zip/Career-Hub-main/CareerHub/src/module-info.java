/**
 * 
 */
/**
 * 
 */
module CareerHub {
	requires java.sql;
}