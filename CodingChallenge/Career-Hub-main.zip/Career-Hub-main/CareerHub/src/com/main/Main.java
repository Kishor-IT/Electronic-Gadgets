package com.main;

import com.dao.*;
import com.entity.*;
import com.util.DbPropertyUtil;
import com.util.DbConnectUtil;

import java.sql.Connection;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        ApplicantDao applicantDao = new ApplicantDaoImpl();
        JobDao jobDao = new JobDaoImpl();
        CompanyDao companyDao = new CompanyDaoImpl();
        JobApplicationDao jobAppDao = new JobApplicationDaoImpl();

        Properties props = DbPropertyUtil.loadProperties("db.properties");
        System.out.println("Database Properties Loaded:");
        System.out.println("URL: " + props.getProperty("db.url"));
        System.out.println("Username: " + props.getProperty("db.username"));

        Connection testConn = DbConnectUtil.getConnection("db.properties");
        if (testConn == null) {
            System.out.println(" ERROR: Unable to establish database connection. Please check db.properties.");
            return;
        }

        int choice;

        do {
            System.out.println("\n===== CareerHub Menu =====");
            System.out.println("1. Register New Applicant");
            System.out.println("2. View All Job Listings");
            System.out.println("3. Apply for a Job");
            System.out.println("4. Post a Job (Company)");
            System.out.println("5. Search Jobs by Salary Range");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();
            sc.nextLine(); 

            switch (choice) {
                case 1:
                    System.out.println("\n--- Register Applicant ---");
                    System.out.print("First Name: ");
                    String fname = sc.nextLine();
                    System.out.print("Last Name: ");
                    String lname = sc.nextLine();
                    System.out.print("Email: ");
                    String email = sc.nextLine();
                    System.out.print("Phone: ");
                    String phone = sc.nextLine();
                    System.out.print("Resume Summary: ");
                    String resume = sc.nextLine();

                    Applicant newApplicant = new Applicant(0, fname, lname, email, phone, resume);
                    applicantDao.createProfile(newApplicant);
                    break;

                case 2:
                    System.out.println("\n--- Job Listings ---");
                    List<Job> jobs = jobDao.getAllJobListings();
                    jobs.forEach(System.out::println);
                    break;

                case 3:
                    System.out.println("\n--- Apply for a Job ---");
                    System.out.print("Applicant ID: ");
                    int appId = sc.nextInt();
                    System.out.print("Job ID: ");
                    int jobId = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Cover Letter: ");
                    String cover = sc.nextLine();

                    JobApplication application = new JobApplication(0, jobId, appId, null, cover);
                    jobAppDao.applyToJob(application);
                    break;

                case 4:
                    System.out.println("\n--- Post a Job ---");
                    System.out.print("Company ID: ");
                    int compId = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Job Title: ");
                    String title = sc.nextLine();
                    System.out.print("Description: ");
                    String desc = sc.nextLine();
                    System.out.print("Location: ");
                    String loc = sc.nextLine();
                    System.out.print("Salary: ");
                    double salary = sc.nextDouble();
                    sc.nextLine();
                    System.out.print("Job Type (Full-time/Part-time/Contract): ");
                    String type = sc.nextLine();

                    Job job = new Job(0, compId, title, desc, loc, salary, type, null);
                    companyDao.postJob(job);
                    break;

                case 5:
                    System.out.println("\n--- Search by Salary Range ---");
                    System.out.print("Min Salary: ");
                    double min = sc.nextDouble();
                    System.out.print("Max Salary: ");
                    double max = sc.nextDouble();

                    List<Job> rangeJobs = jobDao.getJobsBySalaryRange(min, max);
                    rangeJobs.forEach(System.out::println);
                    break;

                case 0:
                    System.out.println("Thank You !!!");
                    break;

                default:
                    System.out.println("Invalid choice! Try again.");
            }

        } while (choice != 0);

        sc.close();
    }
}
