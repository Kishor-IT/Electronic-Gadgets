package com.dao;

import com.entity.Job;
import java.util.List;

public interface JobDao {
    List<Job> getAllJobListings();
    
    List<Job> getJobsBySalaryRange(double min, double max);
    
    Job getJobById(int jobId);
}
