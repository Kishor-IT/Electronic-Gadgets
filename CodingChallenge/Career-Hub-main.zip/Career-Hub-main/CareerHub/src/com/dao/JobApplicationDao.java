package com.dao;

import com.entity.JobApplication;

import java.util.List;

public interface JobApplicationDao {
	
    void applyToJob(JobApplication application);
    
    List<JobApplication> getApplicationsForJob(int jobId);
}
