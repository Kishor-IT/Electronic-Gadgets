package com.dao;


import com.entity.Applicant;

import java.util.List;

public interface ApplicantDao {
	
    void createProfile(Applicant applicant);
    
    List<Applicant> getAllApplicants();
    
    Applicant getApplicantByEmail(String email); 
}

