package com.dao;

import com.entity.Applicant;
import com.util.DbConnectUtil;
import com.exception.InvalidEmailException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ApplicantDaoImpl implements ApplicantDao {

    private final String dbFile = "db.properties";

    @Override
    public void createProfile(Applicant applicant) {
        if (!applicant.getEmail().contains("@") || !applicant.getEmail().contains(".")) {
            try {
                throw new InvalidEmailException("Invalid email format: " + applicant.getEmail());
            } catch (InvalidEmailException e) {
                System.out.println(e.getMessage());
                return;
            }
        }

        String query = "INSERT INTO Applicants (FirstName, LastName, Email, Phone, Resume) VALUES (?, ?, ?, ?, ?)";

        Connection connection = DbConnectUtil.getConnection(dbFile);
        if (connection == null) {
            System.out.println("Cannot create profile: No database connection.");
            return;
        }

        try (PreparedStatement statement = connection.prepareStatement(query)) {
        	statement.setString(1, applicant.getFirstName());
        	statement.setString(2, applicant.getLastName());
        	statement.setString(3, applicant.getEmail());
        	statement.setString(4, applicant.getPhone());
        	statement.setString(5, applicant.getResume());

        	statement.executeUpdate();
            System.out.println("Applicant profile created successfully!");

        } catch (SQLException e) {
            System.out.println("Error found in creating applicant profile: " + e.getMessage());
        }
    }

    @Override
    public List<Applicant> getAllApplicants() {
        List<Applicant> applicants = new ArrayList<>();
        String query = "SELECT * FROM Applicants";

        Connection connection = DbConnectUtil.getConnection(dbFile);
        if (connection == null) {
            System.out.println("Cannot retrieve applicants: No database connection.");
            return applicants;
        }

        try (Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery(query)) {

            while (result.next()) {
                Applicant app = new Applicant(
                		result.getInt("ApplicantId"),
                		result.getString("FirstName"),
                		result.getString("LastName"),
                		result.getString("Email"),
                		result.getString("Phone"),
                		result.getString("Resume")
                );
                applicants.add(app);
            }

        } catch (SQLException e) {
            System.out.println("Error found in retrieving applicants: " + e.getMessage());
        }

        return applicants;
    }

    @Override
    public Applicant getApplicantByEmail(String email) {
        Applicant applicant = null;
        String query = "SELECT * FROM Applicants WHERE Email = ?";

        Connection connection = DbConnectUtil.getConnection(dbFile);
        if (connection == null) {
            System.out.println("Cannot search applicant: No database connection.");
            return null;
        }

        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, email);
            ResultSet result = statement.executeQuery();

            if (result.next()) {
                applicant = new Applicant(
                		result.getInt("ApplicantId"),
                		result.getString("FirstName"),
                		result.getString("LastName"),
                		result.getString("Email"),
                		result.getString("Phone"),
                		result.getString("Resume")
                );
            }

        } catch (SQLException e) {
            System.out.println("Error finding applicant: " + e.getMessage());
        }

        return applicant;
    }
}
