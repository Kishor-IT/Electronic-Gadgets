package com.dao;

import com.entity.Job;
import com.exception.NonNegativeSalaryException;
import com.util.DbConnectUtil;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class JobDaoImpl implements JobDao {

    private final String dbFile = "db.properties";

    @Override
    public List<Job> getAllJobListings() {
        List<Job> jobs = new ArrayList<>();
        String query = "SELECT * FROM Jobs";

        Connection connection = DbConnectUtil.getConnection(dbFile);
        if (connection == null) {
            System.out.println("Cannot fetch job listings: No database connection.");
            return jobs;
        }

        try (Statement statement = connection.createStatement();
             ResultSet result = statement.executeQuery(query)) {

            while (result.next()) {
                Job job = new Job(
                		result.getInt("JobId"),
                		result.getInt("CompanyId"),
                		result.getString("JobTitle"),
                		result.getString("JobDescription"),
                		result.getString("JobLocation"),
                		result.getDouble("Salary"),
                		result.getString("JobType"),
                		result.getTimestamp("PostedDate").toLocalDateTime()
                );
                jobs.add(job);
            }

        } catch (SQLException e) {
            System.out.println("Error found in fetching jobs: " + e.getMessage());
        }

        return jobs;
    }

    @Override
    public List<Job> getJobsBySalaryRange(double min, double max) {
        List<Job> jobs = new ArrayList<>();

        try {
            if (min < 0 || max < 0) {
                throw new NonNegativeSalaryException("Salary range cannot have negative values.");
            }

            String query = "SELECT * FROM Jobs WHERE Salary BETWEEN ? AND ?";

            Connection conn = DbConnectUtil.getConnection(dbFile);
            if (conn == null) {
                System.out.println("Cannot filter by salary range: No database connection.");
                return jobs;
            }

            try (PreparedStatement statement = conn.prepareStatement(query)) {
            	statement.setDouble(1, min);
            	statement.setDouble(2, max);
                ResultSet result = statement.executeQuery();

                while (result.next()) {
                    Job job = new Job(
                    		result.getInt("JobId"),
                    		result.getInt("CompanyId"),
                    		result.getString("JobTitle"),
                    		result.getString("JobDescription"),
                    		result.getString("JobLocation"),
                    		result.getDouble("Salary"),
                    		result.getString("JobType"),
                    		result.getTimestamp("PostedDate").toLocalDateTime()
                    );
                    jobs.add(job);
                }
            }

        } catch (NonNegativeSalaryException e) {
            System.out.println(e.getMessage());
        } catch (SQLException e) {
            System.out.println("Error found in fetching jobs by salary range: " + e.getMessage());
        }

        return jobs;
    }

    @Override
    public Job getJobById(int jobId) {
        Job job = null;
        String query = "SELECT * FROM Jobs WHERE JobId = ?";

        Connection conn = DbConnectUtil.getConnection(dbFile);
        if (conn == null) {
            System.out.println("Cannot get job: No database connection.");
            return null;
        }

        try (PreparedStatement statement = conn.prepareStatement(query)) {
        	statement.setInt(1, jobId);
            ResultSet result = statement.executeQuery();

            if (result.next()) {
                job = new Job(
                		result.getInt("JobId"),
                		result.getInt("CompanyId"),
                		result.getString("JobTitle"),
                		result.getString("JobDescription"),
                		result.getString("JobLocation"),
                		result.getDouble("Salary"),
                		result.getString("JobType"),
                		result.getTimestamp("PostedDate").toLocalDateTime()
                );
            }

        } catch (SQLException e) {
            System.out.println("Error fetching job by ID: " + e.getMessage());
        }

        return job;
    }
}
