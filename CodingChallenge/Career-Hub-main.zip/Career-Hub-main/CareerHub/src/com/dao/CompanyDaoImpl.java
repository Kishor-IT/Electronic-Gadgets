package com.dao;

import com.entity.Company;
import com.entity.Job;
import com.util.DbConnectUtil;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class CompanyDaoImpl implements CompanyDao {

    private final String dbFile = "db.properties";

    @Override
    public void postJob(Job j) {
        String query = "INSERT INTO Jobs (CompanyId, JobTitle, JobDescription, JobLocation, Salary, JobType, PostedDate) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection connection = DbConnectUtil.getConnection(dbFile);
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, j.getCompanyId());
            statement.setString(2, j.getJobTitle());
            statement.setString(3, j.getJobDescription());
            statement.setString(4, j.getJobLocation());
            statement.setDouble(5, j.getSalary());
            statement.setString(6, j.getJobType());
            statement.setTimestamp(7, Timestamp.valueOf(LocalDateTime.now()));

            statement.executeUpdate();
            System.out.println("Job posted successfully!");

        } catch (SQLException e) {
            System.out.println("Error found in posting job: " + e.getMessage());
        }
    }

    @Override
    public List<Job> getJobsByCompanyId(int companyId) {
        List<Job> jobs = new ArrayList<>();
        String query = "SELECT * FROM Jobs WHERE CompanyId = ?";

        try (Connection connection = DbConnectUtil.getConnection(dbFile);
             PreparedStatement statement = connection.prepareStatement(query)) {

        	statement.setInt(1, companyId);
            ResultSet result = statement.executeQuery();

            while (result.next()) {
                Job j = new Job(
                	result.getInt("JobId"),
                	result.getInt("CompanyId"),
                	result.getString("JobTitle"),
                	result.getString("JobDescription"),
                	result.getString("JobLocation"),
                	result.getDouble("Salary"),
                	result.getString("JobType"),
                	result.getTimestamp("PostedDate").toLocalDateTime()
                );
                jobs.add(j);
            }

        } catch (SQLException e) {
            System.out.println("Error found in fetching jobs: " + e.getMessage());
        }

        return jobs;
    }

    @Override
    public void insertCompany(Company company) {
        String query = "INSERT INTO Company (CompanyName, Location) VALUES (?, ?)";

        try (Connection connection = DbConnectUtil.getConnection(dbFile);
             PreparedStatement statement = connection.prepareStatement(query)) {

        	statement.setString(1, company.getCompanyName());
        	statement.setString(2, company.getLocation());

        	statement.executeUpdate();
            System.out.println("Company inserted successfully!");

        } catch (SQLException e) {
            System.out.println("Error found in inserting company: " + e.getMessage());
        }
    }

    @Override
    public List<Company> getAllCompanies() {
        List<Company> companies = new ArrayList<>();
        String query = "SELECT * FROM Company";

        try (Connection connection = DbConnectUtil.getConnection(dbFile);
             Statement statement = connection.createStatement()) {

            ResultSet result = statement.executeQuery(query);
            while (result.next()) {
                Company company = new Company(
                	result.getInt("CompanyID"),
                	result.getString("CompanyName"),
                	result.getString("Location")
                );
                companies.add(company);
            }

        } catch (SQLException e) {
            System.out.println("Error found in retrieving companies: " + e.getMessage());
        }

        return companies;
    }
}
