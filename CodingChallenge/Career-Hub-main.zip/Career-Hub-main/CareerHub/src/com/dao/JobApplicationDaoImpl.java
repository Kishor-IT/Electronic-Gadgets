package com.dao;

import com.entity.JobApplication;
import com.util.DbConnectUtil;
import com.exception.ApplicationDeadlineException;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class JobApplicationDaoImpl implements JobApplicationDao {

    private final String dbFile = "db.properties";

    @Override
    public void applyToJob(JobApplication application) {
        try {
            String jobQuery = "SELECT PostedDate FROM Jobs WHERE JobId = ?";
            try (Connection connection = DbConnectUtil.getConnection(dbFile);
                 PreparedStatement statement = connection.prepareStatement(jobQuery)) {

                statement.setInt(1, application.getJobId());
                ResultSet result = statement.executeQuery();

                if (result.next()) {
                    LocalDateTime postedDate = result.getTimestamp("PostedDate").toLocalDateTime();
                    LocalDateTime deadline = postedDate.plusDays(30);
                    if (LocalDateTime.now().isAfter(deadline)) {
                        throw new ApplicationDeadlineException("The application deadline has passed.");
                    }
                }
            }

            String insertQuery = "INSERT INTO Applications (JobId, ApplicantId, ApplicationDate, CoverLetter) VALUES (?, ?, ?, ?)";
            try (Connection connection = DbConnectUtil.getConnection(dbFile);
                 PreparedStatement statement = connection.prepareStatement(insertQuery)) {

                statement.setInt(1, application.getJobId());
                statement.setInt(2, application.getApplicantId());
                statement.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));
                statement.setString(4, application.getCoverLetter());

                statement.executeUpdate();
                System.out.println("Application submitted successfully!");
            }

        } catch (ApplicationDeadlineException e) {
            System.out.println(e.getMessage());
        } catch (SQLException e) {
            System.out.println("Error found in submitting application: " + e.getMessage());
        }
    }

    @Override
    public List<JobApplication> getApplicationsForJob(int jobId) {
        List<JobApplication> applications = new ArrayList<>();
        String query = "SELECT * FROM Applications WHERE JobId = ?";

        try (Connection connection = DbConnectUtil.getConnection(dbFile);
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, jobId);
            ResultSet result = statement.executeQuery();

            while (result.next()) {
                JobApplication app = new JobApplication(
                		result.getInt("ApplicationId"),
                		result.getInt("JobId"),
                		result.getInt("ApplicantId"),
                		result.getTimestamp("ApplicationDate").toLocalDateTime(),
                		result.getString("CoverLetter")
                );
                applications.add(app);
            }

        } catch (SQLException e) {
            System.out.println("Error found in fetching applications: " + e.getMessage());
        }

        return applications;
    }
}
