package com.dao;

import com.entity.Company;
import com.entity.Job;
import java.util.List;

public interface CompanyDao {
    void postJob(Job j);
    
    List<Job> getJobsByCompanyId(int companyId);
    
    void insertCompany(Company company);
    
    List<Company> getAllCompanies();
}
