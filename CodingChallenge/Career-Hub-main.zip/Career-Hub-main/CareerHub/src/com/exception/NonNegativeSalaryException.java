package com.exception;
	   
public class NonNegativeSalaryException extends Exception {
       public NonNegativeSalaryException(String message) {
	      super(message);
   }
}
