package com.exception;

public class FileUploadException extends Exception {
   public FileUploadException(String message) {
	   super(message);
   }
}
